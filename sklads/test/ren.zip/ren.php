<?
include "../../lib/sql.php";

if (!mySQLconnect()) {
	my_error();
}

$skl[1] = 'him';
$skl[2] = 'mat';
$skl[3] = 'him1';
$skl[4] = 'sver';
$skl[5] = 'hal';
$skl[6] = 'inst';
$skl[7] = 'nepon';
$skl[8] = 'maloc';
$skl[9] = 'test';


for ($i=1;$i<10;$i++) {
	$sklad = $skl[$i];
	$sql = "RENAME TABLE `sk_".$sklad."_dvizh_arc` TO `sk_".$sklad."__dvizh_arc`";
	debug($sql);
	if (!mysql_query($sql)) 
		my_error();
	$sql = "RENAME TABLE `sk_".$sklad."_dvizh` TO `sk_".$sklad."__dvizh`";
	debug($sql);
	if (!mysql_query($sql)) 
		my_error();
	$sql = "RENAME TABLE `sk_".$sklad."_spr` TO `sk_".$sklad."__spr`";
	debug($sql);
	if (!mysql_query($sql)) 
		my_error();
	$sql = "RENAME TABLE `sk_".$sklad."_ost` TO `sk_".$sklad."__ost`";
	debug($sql);
	if (!mysql_query($sql)) 
		my_error();
	$sql = "RENAME TABLE `sk_".$sklad."_postav` TO `sk_".$sklad."__postav`";
	debug($sql);
	if (!mysql_query($sql)) 
		my_error();
	$sql = "RENAME TABLE `sk_arc_".$sklad."_dvizh` TO `sk_arc_".$sklad."__dvizh`";
	debug($sql);
	if (!mysql_query($sql)) 
		my_error();
	$sql = "RENAME TABLE `sk_arc_".$sklad."_spr` TO `sk_arc_".$sklad."__spr`";
	debug($sql);
	if (!mysql_query($sql)) 
		my_error();
	$sql = "RENAME TABLE `sk_arc_".$sklad."_ost` TO `sk_arc_".$sklad."__ost`";
	debug($sql);
	if (!mysql_query($sql)) 
		my_error();
}
?>