<?
function debug($text) {
	if (1) {
		print $text."<br>\n";
	}
}

function my_error()
{
	print "99999999";
	exit;
}

function mySQLconnect()
{
	$mysql_host= 'localhost';
	$mysql_login='root';
	$mysql_password='';
	$mysql_db='zaompp';

	if( !mysql_connect($mysql_host,$mysql_login,$mysql_password) ) {
		return 0;
	}
	if( !mysql_select_db($mysql_db) ) return 0;
	mysql_query("set names cp1251");
	return 1;
}

if (!mySQLconnect()) {
	my_error();
}

// CREATE TABLE `zaompp`.`sk_hal` (`1` BIGINT( 10 ) NOT NULL) TYPE = MYISAM
// DROP IF EXIST TABLE `sk_hal`

/*
$sql = "DROP IF EXIST TABLE `sk_hal_spr`";
debug($sql);
if (!mysql_query($sql)) 
	my_error();
*/
$sql = "DROP TABLE IF EXISTS `sk_hal_dvizh`";
debug($sql);
if (!mysql_query($sql)) 
	my_error();
/*
$sql = "DROP IF EXIST TABLE `sk_hal_ost`";
debug($sql);
if (!mysql_query($sql)) 
	my_error();
$sql = "DROP IF EXIST TABLE `sk_hal_reestr`";
debug($sql);
if (!mysql_query($sql)) 
	my_error();
*/

$sql = "CREATE TABLE `zaompp`.`sk_hal_dvizh` (`id` BIGINT( 10 ) NOT NULL AUTO_INCREMENT,`type` BOOL NOT NULL ,`numd` VARCHAR( 10 ) NOT NULL ,`numdf` VARCHAR( 10 ) NOT NULL ,`docyr` INT NOT NULL ,`spr_id` BIGINT( 10 ) NOT NULL ,`quant` FLOAT NOT NULL ,`ddate` DATE NOT NULL ,`post_id` BIGINT( 10 ) NOT NULL ,`comment_id` BIGINT( 10 ) NOT NULL ,`price` FLOAT NOT NULL ,PRIMARY KEY ( `id` ) ,INDEX ( `type` ) ) TYPE = MYISAM";
debug($sql);
if (!mysql_query($sql)) 
	my_error();

$sql = "CREATE TABLE IF NOT EXISTS `zaompp`.`sk_hal_postav` (`id` BIGINT( 10 ) NOT NULL AUTO_INCREMENT,`supply` VARCHAR( 30 ) NOT NULL , PRIMARY KEY ( `id` ) ) TYPE = MYISAM";
debug($sql);
if (!mysql_query($sql)) 
	my_error();

if (!$file=fopen("doc.txt","r"))
	my_error();

$str = fgets($file);// ����� ������ � ������� �����
while (!feof ($file)) {
	$str = fgets($file, 4096);
	if (!$str) exit;
	$str = str_replace('"','',$str);
	list($type,$numd,$numf,$docyr,$spr,$quant,$ddate,$postav,$comment,$price)=explode(",",$str);
	$type = ($type=='������')?"1":"0";
	$sql = "SELECT DATE_ADD( '1800-12-28', INTERVAL $ddate DAY )";
	debug($sql);
	$rs = mysql_fetch_array(mysql_query($sql));
	$ddate = $rs[0];
	// ������ ����������
	$sql="SELECT id FROM sk_hal_postav WHERE supply='$postav'";
	debug($sql);
	$res = mysql_query($sql);
	if ($rs=mysql_fetch_array($res)){
		$post_id = $rs["id"];
	} else {
		$sql="INSERT INTO sk_hal_postav (supply) VALUES ('$postav')";
		debug($sql);
		mysql_query($sql);
		$post_id = mysql_insert_id();
		if (!$post_id) my_error();
	}
	// ��������� ������������� ����������
	$sql="SELECT id FROM coments WHERE comment='$comment'";
	debug($sql);
	$res = mysql_query($sql);
	if ($rs=mysql_fetch_array($res)){
		$comment_id = $rs["id"];
	} else {
		$sql="INSERT INTO coments (comment) VALUES ('$comment')";
		debug($sql);
		mysql_query($sql);
		$comment_id = mysql_insert_id();
		if (!$comment_id) my_error();
	}
	
	// ������� ����� ��������
	$sql="INSERT INTO sk_hal_dvizh (type,numd,numdf,docyr,spr_id,quant,ddate,post_id,comment_id,price) VALUES ('$type','$numd','$numf','$docyr','$spr','$quant','$ddate','$post_id','$comment_id','$price')";
	debug($sql);
	if(!mysql_query($sql)) 
		my_error();
}
fclose ($file);





?>