<?
function debug($text) {
	if (1) {
		print $text."<br>\n";
	}
}

function my_error()
{
	print "99999999";
	exit;
}

function mySQLconnect()
{
	$mysql_host= 'localhost';
	$mysql_login='root';
	$mysql_password='';
	$mysql_db='zaompp';

	if( !mysql_connect($mysql_host,$mysql_login,$mysql_password) ) {
		return 0;
	}
	if( !mysql_select_db($mysql_db) ) return 0;
	mysql_query("set names cp1251");
	return 1;
}

if (!mySQLconnect()) {
	my_error();
}

// CREATE TABLE `zaompp`.`sk_inst` (`1` BIGINT( 10 ) NOT NULL) TYPE = MYISAM
// DROP IF EXIST TABLE `sk_inst`


$sql = "DROP TABLE IF EXISTS `sk_inst_spr`";
debug($sql);
if (!mysql_query($sql)) 
	my_error();

$sql = "DROP TABLE IF EXISTS `sk_inst_ost`";
debug($sql);
if (!mysql_query($sql)) 
	my_error();
/*
$sql = "DROP IF EXIST TABLE `sk_inst_reestr`";
debug($sql);
if (!mysql_query($sql)) 
	my_error();
*/

$sql = "CREATE TABLE `zaompp`.`sk_inst_spr` (`id` BIGINT( 10 ) NOT NULL AUTO_INCREMENT, `nazv` VARCHAR( 50 ) NOT NULL ,`edizm` VARCHAR( 10 ) NOT NULL ,`krost` FLOAT NOT NULL ,PRIMARY KEY ( `id` ) ) TYPE = MYISAM";
debug($sql);
if (!mysql_query($sql)) 
	my_error();

$sql = "CREATE TABLE IF NOT EXISTS `zaompp`.`sk_inst_ost` (`id` BIGINT( 10 ) NOT NULL AUTO_INCREMENT, `spr_id` BIGINT( 10 ) NOT NULL,`ost` FLOAT NOT NULL , PRIMARY KEY ( `id` ) ) TYPE = MYISAM";
debug($sql);
if (!mysql_query($sql)) 
	my_error();

if (!$file=fopen("reac.txt","r"))
	my_error();

$str = fgets($file);// ����� ������ � ������� �����
while (!feof ($file)) {
	$str = fgets($file, 4096);
	if (!$str) exit;
	$str = ereg_replace('"([^",]+),([^,"]+)"','"\\1;\\2"',$str);
	$str = str_replace('"','',$str);
	list($id,$arch,$nazv,$edizm,$ost,$krost,$pro,$flag,$flagg)=explode(",",$str);
	$nazv = str_replace(";",",",$nazv);
	// ������� ����� ��������
	$sql="INSERT INTO sk_inst_spr (id,nazv,edizm,krost) VALUES ('$id','$nazv','$edizm','$krost')";
	debug($sql);
	if(!mysql_query($sql)) 
		my_error();
	$sql="INSERT INTO sk_inst_ost (spr_id,ost) VALUES ('$id','$ost')";
	debug($sql);
	if(!mysql_query($sql)) 
		my_error();
}
fclose ($file);





?>